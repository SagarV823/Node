const geocode = require('./utils/geocode')
const forecast = require('./utils/forecast')

console.log(process.argv[2])
const address = process.argv[2];

if (!address) {
    console.log('Please provide a location')
}
else {
    geocode(address, (error, {latitude,longitude,location}={}) => {

        if (error) {
            return console.log("Error: ", error)
        }
        forecast(latitude, longitude, (error, forecastdata) => {
            if (error) {
                return console.log('Error: ', error)
            }
            console.log(location)
            console.log(forecastdata)
        })
    })
}
// else {
//     geocode(address, (error, data) => {

//         if (error) {
//             return console.log("Error: ", error)
//         }
//         forecast(data.latitude, data.longitude, (error, forecastdata) => {
//             if (error) {
//                 return console.log('Error: ', error)
//             }
//             console.log(data.location)
//             console.log(forecastdata)
//         })
//     })
// }