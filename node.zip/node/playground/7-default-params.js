const greeter=(name="Person",age=24)=>{
    console.log('Hello ',name)
    console.log('Age is: ',age)
}
greeter("Sagar")

greeter()