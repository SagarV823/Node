// const square=function (x){
//     return x*x;
// }
// const square=(x)=>{
//     return x*x
// }
//short hand syntax for just a single statement, automaticaly returns as well
// const square=(x)=>x*x
// console.log(square(3))
// const event={
//     name:'Birthday Party!',
//     printGuestList: function(){
//         console.log('Guesst list for '+this.name)
//     }
// }
const event={
    name:'Birthday Party!',
    guestList:['Sagar','Sahil','Piyush'],
    printGuestList(){
        console.log('Guesst list for '+this.name)
        this.guestList.forEach(function(guest){
            console.log(guest+' is attending '+this.name)
        })
        this.guestList.forEach((guest)=>{
            console.log(guest+' is attending '+this.name)
        })
        for(let guest of this.guestList){
            console.log(guest+' is attending '+this.name)
        }
    }
}
event.printGuestList()