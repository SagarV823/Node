const name = 'Sagar'
const userAge = 27

// const user={
//     name:name,
//     userAge:userAge,
//     location:'Sonipat'
// }
//shorthand syntax
// const user={
//     name,
//     userAge:userAge,
//     location:'Sonipat'
// }
// console.log(user)

//object destructuring 

const product = {
    label: 'Red Notebook',
    price: 3,
    stock: 201,
    salePrice: undefined,
    rating: 4.2
}

// const { label: productLabel, price, stock, salePrice, rating = 5 } = product
// console.log(productLabel)
// console.log(stock)
// console.log(rating)

// const transaction=(type,myProduct)=>{

// }
//destructuring
const transaction=(type,{label,stock})=>{
    console.log(label)
    console.log(stock)
}   

transaction('order',product)