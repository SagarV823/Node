const fs=require('fs')

const data=fs.readFileSync('1-json.json')
const infoJSON=JSON.parse(data)

infoJSON.name='Sagar'
infoJSON.age=23

const infoString=JSON.stringify(infoJSON);
console.log(infoString)
fs.writeFileSync('1-json.json',infoString)
console.log(infoJSON)