const fs = require('fs')
const chalk = require('chalk')


const loadNotes = () => {

    try {
        const dataBuffer = fs.readFileSync('notes.json')
        const dataJSON = dataBuffer.toString();
        return JSON.parse(dataJSON)
    }
    catch (e) {
        return []
    }
}

const addNote = (title, body) => {
    const notes = loadNotes()
    const duplicateNote = notes.find((note) => note.title === title)
    if (!duplicateNote) {

        notes.push({
            title: title,
            body: body
        })
        saveNotes(notes)
        console.log(chalk.green("Note added!"))
    } else {
        console.log(chalk.red("Title is taked, use different title!"))
    }
}

const removeNote = (title) => {
    const notes = loadNotes()

    const notesToKeep = notes.filter((note) => note.title !== title)
    if (notes.length == notesToKeep.length) {
        console.log(chalk.red("note not found"))
    }
    else {
        console.log(chalk.green(title, " is removed"))
        saveNotes(notesToKeep)
    }
}

const saveNotes = (notes) => {
    const dataJSON = JSON.stringify(notes)
    fs.writeFileSync('notes.json', dataJSON);
}

const listNotes = () => {
    console.log(chalk.blue.inverse("Your notes!"))
    const notes = loadNotes()
    notes.forEach(note => {
        console.log(note.title)
    });
}

const readNote = (title) => {
    const notes = loadNotes()
    const rnote = notes.find((note) => note.title === title)
    if (rnote) {
        console.log(chalk.green.bold(rnote.title));
        console.log(rnote.body)
    }else{
        console.log(chalk.red("note not found"));
    }
}
module.exports = {
    listNotes: listNotes,
    addNote: addNote,
    removeNote: removeNote,
    readNote: readNote
};